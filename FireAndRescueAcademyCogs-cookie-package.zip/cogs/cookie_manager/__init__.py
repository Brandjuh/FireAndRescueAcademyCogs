from .cookie_manager import setup

__all__ = ["setup"]
